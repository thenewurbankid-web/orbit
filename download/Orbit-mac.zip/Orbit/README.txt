Orbit 1.1.0

Orbit shows the AI companies you run in Paperclip, live, on https://thenewurbankid-web.github.io/orbit/

Double-click "Start Orbit" (the first time: right-click it and choose Open).
It copies Orbit into your user folder, starts it now and at every login (no admin needed), and opens
the Orbit page. Then press "Connect to this computer" there and Allow.

To remove it: double-click "Uninstall Orbit", or use Uninstall in Orbit's control centre.
Orbit needs Node.js 20 or newer, which Paperclip already uses.
